A place for writing about random technical things.

[http://narula.github.io](http://narula.github.io)